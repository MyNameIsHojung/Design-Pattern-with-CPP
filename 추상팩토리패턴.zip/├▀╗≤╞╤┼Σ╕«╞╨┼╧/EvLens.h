#pragma once
#include "Lens.h"
class EvLens : public Lens
{
public:
	virtual void Take();

public:
	void AutoFocus();

};

