#pragma once
class Lens
{
public:
	virtual void Take() = 0;
};


